﻿namespace Exam1.QH.CategoryQh
{
    public class CategoryQuery
    {
    }
}
