﻿using Exam1.Model;

namespace Exam1.Repo.PurchaseRepoA
{
    public interface IPurches:IPurchesRepositories<UserPurch>
    {
    }
}
