﻿using Exam1.Model;

namespace Exam1.Repo.AdminRepoA
{
    public interface IAdmin:IAdminRepositories<Produ>
    {
    }
}
