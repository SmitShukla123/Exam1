﻿using Exam1.Models;

namespace Exam1.Repo.UserReopA
{
    public interface IUserRepo:IUserRepositories<User>
    {
    }
}
