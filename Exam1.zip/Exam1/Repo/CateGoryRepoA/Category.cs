﻿namespace Exam1.Repo.CateGoryRepoA
{
    public class Category
    {
    }
}
