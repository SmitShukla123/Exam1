﻿namespace Exam1.Repo.CateGoryRepoA
{
    public interface ICategoryRepositories
    {
    }
}
