﻿namespace Exam1.Model
{
    public class Catego
    {
        public int cid { get; set; }
        public string? cname { get; set; }
    }
}
